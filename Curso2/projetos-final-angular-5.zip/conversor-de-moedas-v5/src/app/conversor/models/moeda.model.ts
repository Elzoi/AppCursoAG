export class Moeda {
	
	constructor(
		public sigla?: string,
		public descricao?: string) {}
}
